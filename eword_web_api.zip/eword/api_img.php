<?php
/** 
  * @desc Mã nguồn ứng dụng học từ vựng tiếng Anh EWORD
  * @author Nguyễn Trung Nhẫn trungnhan0911@yandex.com
*/
//https://pixabay.com/api/?key=15391967-870f45f63cf88ef052abd0dc5&q=yellow+flowers&image_type=all&pretty=true&lang=vi&orientation=horizontal&per_page=3

if (isset($_GET['key'])) {
    $key = trim($_GET['key']);
    $getkk = file_get_contents('https://pixabay.com/api/?key=15391967-870f45f63cf88ef052abd0dc5&q='.$key.'&image_type=all&pretty=true&lang=vi&orientation=horizontal&per_page=3&safesearch=true');
    $obj = json_decode($getkk, true); 
  //  print $obj->{'geeks'}; 
  $rand = rand(0,1);
//$link_img =  $obj['hits']['0']['webformatURL'];
//if ($rand == 0) {
 
//} else if ($rand == 1) {
    if (isset($obj['hits']['1']['webformatURL'])) {
    echo $obj['hits']['1']['webformatURL'];
} else {
  //  echo "https://i.imgur.com/B1Q9h26.png";
     if (isset($obj['hits']['0']['webformatURL'])) {
    echo $obj['hits']['0']['webformatURL'];
} else {
    echo "https://i.imgur.com/B1Q9h26.png";
}
} 
//} 


  //  var_dump ($obj);
}