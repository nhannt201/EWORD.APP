<?php
/** 
  * @desc Mã nguồn ứng dụng học từ vựng tiếng Anh EWORD
  * @author Nguyễn Trung Nhẫn trungnhan0911@yandex.com
*/
$servername = "localhost";
$username = "";
$password = "";
$dbname = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn->set_charset("utf8")) { }
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['email'])) {

$mail= trim($_GET['email']);
$name = trim($_GET['name']);
$rank = trim($_GET['rank']);

//$val = mysqli_query($conn,"select email='$namefile' from  eword");
$query = mysqli_query($conn, "SELECT * FROM ew_bxh WHERE mail='".$mail."'");

if(mysqli_num_rows($query) > 0)
{
        $row = mysqli_fetch_assoc($query);
  
   if ($rank == 1) {
     $sql = "UPDATE ew_bxh SET rank=rank+10 WHERE mail='$mail'";

} elseif  ($rank == 0) {
          if ($row["rank"] >= 20) {
                   $sql = "UPDATE ew_bxh SET rank=rank-20 WHERE mail='$mail'";

        } else {
                   $sql = "UPDATE ew_bxh SET rank=0 WHERE mail='$mail'";

        }

}

if (mysqli_query($conn, $sql)) {
   // echo "Record updated successfully";
} else {
 //   echo "Error updating record: " . mysqli_error($conn);
}
}
else
{
      if ($rank == 1) { 
          $rank = 10;
      } elseif ($rank == 0) {
          $rank = 0;
      }
    //I can't find it...
    $sql = "INSERT INTO ew_bxh (name, mail,rank)
VALUES ('$name', '$mail', '$rank')";
if (mysqli_query($conn, $sql)) {
   // echo "New record created successfully";
} else {
   // echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}
//

}
////unlink($namefile.".jpg");
mysqli_close($conn);