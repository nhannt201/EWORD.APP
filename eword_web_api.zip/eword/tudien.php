<?php
/** 
  * @desc Mã nguồn ứng dụng học từ vựng tiếng Anh EWORD
  * @author Nguyễn Trung Nhẫn trungnhan0911@yandex.com
*/
$servername = "localhost";
$username = "";
$password = "";
$dbname = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn->set_charset("utf8")) { }
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


if (isset($_GET['key'])) {
    $key = trim($_GET['key']);
//    echo $mail;
// Select 1 from table_name will return false if the table does not exist.
//$val = mysqli_query($conn,"select email='$mail' from  eword");
$query = mysqli_query($conn, "SELECT * FROM tudien WHERE en='".$key."'");
if(mysqli_num_rows($query) > 0){

    $row = mysqli_fetch_assoc($query);
    $nghiatv=  (str_replace("-","■ ", $row['vi']));
    $nghiatv=  (str_replace("=","- ", $nghiatv));
     $nghiatv=  (str_replace("+","\n", $nghiatv));
     $nghiatv= nl2br (str_replace("!","▸ ", $nghiatv));
    echo $nghiatv;
   // echo str_replace($nghiatv, "<br />","\n");
}else{
       echo "";
       //ghi vao csdl
          //I can't find it...
    $sql = "INSERT INTO tudien (en, speak, vi)
VALUES ('$key','', '')";
if (mysqli_query($conn, $sql)) {
   // echo "New record created successfully";
} else {
   // echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
       //het ghi
}
	}
	
////unlink($namefile.".jpg");
mysqli_close($conn);