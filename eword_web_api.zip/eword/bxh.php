<?php
/** 
  * @desc Mã nguồn ứng dụng học từ vựng tiếng Anh EWORD
  * @author Nguyễn Trung Nhẫn trungnhan0911@yandex.com
*/
$servername = "localhost";
$username = "";
$password = "";
$dbname = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn->set_charset("utf8")) { }
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$mydate=getdate(date("U"));


//    echo $mail;
// Select 1 from table_name will return false if the table does not exist.
//$val = mysqli_query($conn,"select email='$mail' from  eword");
$query = mysqli_query($conn, "SELECT * from ew_bxh ORDER BY rank + 0 DESC LIMIT 10");
$query2 = mysqli_query($conn, "SELECT * from ew_tuan WHERE id='1'");

if(mysqli_num_rows($query2) > 0){
    $row2 = mysqli_fetch_assoc($query2);

    $datee = date('Y-m-d');
    $num_wk = getWeeks($datee,  date('l'));
    if ($row2['num_day'] == $num_wk) {
        
        
    } else {
        //cap nhat BXH truoc khi xoa
            //cap nhat top 1
              if(mysqli_num_rows($query) > 0){
           $row = mysqli_fetch_assoc($query);
           // echo $row['name']."~". $row['rank']."|";
           $name_us = $row['name'];
              $sql123 = "UPDATE ew_us SET top_solan=top_solan+1 WHERE name='$name_us'";
      if (mysqli_query($conn, $sql123)) { }
                  
              } else {}
            
       //ket thuc top tuan va xoa tuan nay
        //xoa BXH cu
       $sql3 = 'DELETE FROM ew_bxh';
   if (mysqli_query($conn, $sql3)) {
    //  echo "Database dqqwewrw was successfully dropped\n";
    } else {
      //  echo 'Error dropping database: ' . mysql_error() . "\n";
    }

    //Cap nhat tuan
   $sql2 = "UPDATE ew_tuan SET num_day='$num_wk' WHERE id='1'";

if (mysqli_query($conn, $sql2)) {
   // echo "Record updated successfully";
} else {
 //   echo "Error updating record: " . mysqli_error($conn);
}
    }
}
if(mysqli_num_rows($query) > 0){
while($row = mysqli_fetch_assoc($query)) {
    echo $row['name']."~". $row['rank']."|";
}

}else{
       echo "no";
}

	
////unlink($namefile.".jpg");
mysqli_close($conn);


 /**
     * Returns the amount of weeks into the month a date is
     * @param $date a YYYY-MM-DD formatted date
     * @param $rollover The day on which the week rolls over
     */
    function getWeeks($date, $rollover)
    {
        $cut = substr($date, 0, 8);
        $daylen = 86400;

        $timestamp = strtotime($date);
        $first = strtotime($cut . "00");
        $elapsed = ($timestamp - $first) / $daylen;

        $weeks = 1;

        for ($i = 1; $i <= $elapsed; $i++)
        {
            $dayfind = $cut . (strlen($i) < 2 ? '0' . $i : $i);
            $daytimestamp = strtotime($dayfind);

            $day = strtolower(date("l", $daytimestamp));

            if($day == strtolower($rollover))  $weeks ++;
        }

        return $weeks;
    }
