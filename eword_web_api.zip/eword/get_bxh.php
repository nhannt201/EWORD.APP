<?php
/** 
  * @desc Mã nguồn ứng dụng học từ vựng tiếng Anh EWORD
  * @author Nguyễn Trung Nhẫn trungnhan0911@yandex.com
*/
$servername = "localhost";
$username = "";
$password = "";
$dbname = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn->set_charset("utf8")) { }
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


if (isset($_GET['email'])) {
    $mail = trim($_GET['email']);
//    echo $mail;
// Select 1 from table_name will return false if the table does not exist.
//$val = mysqli_query($conn,"select email='$mail' from  eword");
$query = mysqli_query($conn, "SELECT * FROM ew_bxh WHERE mail='".$mail."'");
if(mysqli_num_rows($query) > 0){
         $row = mysqli_fetch_assoc($query);
          echo$row['rank'];
    
}else{
      
       echo "no";
}
	}
	
////unlink($namefile.".jpg");
mysqli_close($conn);