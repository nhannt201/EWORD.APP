<?php
/** 
  * @desc Mã nguồn ứng dụng học từ vựng tiếng Anh EWORD
  * @author Nguyễn Trung Nhẫn trungnhan0911@yandex.com
*/
$servername = "localhost";
$username = "";
$password = "";
$dbname = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn->set_charset("utf8")) { }
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


if (isset($_GET['email'])) {
    $mail = trim($_GET['email']);
    $pass = trim($_GET['pass']);
      $name = trim($_GET['name']);
//    echo $mail;
// Select 1 from table_name will return false if the table does not exist.
//$val = mysqli_query($conn,"select email='$mail' from  eword");
$query = mysqli_query($conn, "SELECT * FROM ew_us WHERE email='".$mail."'");
if(mysqli_num_rows($query) > 0){
       /**   $row = mysqli_fetch_assoc($query);
          if ($pass == $row['pass']) {
              echo "yes";
          } else {
                echo "pass_wr";
          } */
            echo "yes";
    
}else{
      $sql = "INSERT INTO ew_us (email, name, pass)
VALUES ('$mail', '$name', '$pass')";
if (mysqli_query($conn, $sql)) {
   // echo "New record created successfully";
} else {
   // echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
       echo "no";
}
	}
	
////unlink($namefile.".jpg");
mysqli_close($conn);