<?php
/** 
  * @desc Mã nguồn ứng dụng học từ vựng tiếng Anh EWORD
  * @author Nguyễn Trung Nhẫn trungnhan0911@yandex.com
*/
$servername = "localhost";
$username = "";
$password = "";
$dbname = "";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn->set_charset("utf8")) { }
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

//	$response = array(); 
	if($_SERVER['REQUEST_METHOD']=='POST'){
	    $namefile = $_POST['name'];//$_FILES["file"]["name"];
				//	$response['name'] = $name;
//
//$myfile   = $_FILES["file"]["name"];
			//	move_uploaded_file($_FILES['image']['tmp_name'],$namefile.".jpg");

	//	move_uploaded_file($_FILES['file']['tmp_name'],"/home/nguyentrungnhan/apps.4it.top/a.txt");
//$myfile   =  $_POST['content'];// (file_get_contents($namefile.".txt"));

$myfile = (file_get_contents($_FILES['image']['tmp_name']));;

// Select 1 from table_name will return false if the table does not exist.
//$val = mysqli_query($conn,"select email='$namefile' from  eword");
$query = mysqli_query($conn, "SELECT * FROM eword WHERE email='".$namefile."'");

if(mysqli_num_rows($query) > 0)
{
   //DO SOMETHING! IT EXISTS!
   $sql = "UPDATE eword SET content='$myfile' WHERE email='$namefile'";

if (mysqli_query($conn, $sql)) {
   // echo "Record updated successfully";
} else {
 //   echo "Error updating record: " . mysqli_error($conn);
}
}
else
{
    //I can't find it...
    $sql = "INSERT INTO eword (email, content)
VALUES ('$namefile', '$myfile')";
if (mysqli_query($conn, $sql)) {
   // echo "New record created successfully";
} else {
   // echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
}
//

}
////unlink($namefile.".jpg");
mysqli_close($conn);