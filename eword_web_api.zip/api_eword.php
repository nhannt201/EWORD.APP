<?php
/** 
  * @desc Mã nguồn ứng dụng học từ vựng tiếng Anh EWORD
  * @author Nguyễn Trung Nhẫn trungnhan0911@yandex.com
*/
if (isset($_GET['text'])) {
    $txt_dich = trim($_GET['text']);
    if (strlen($txt_dich) > 0) {
$yandex_key = "trnsl.1.1.20190406T071915Z.0ee8edd79ffc6da4.58dd9350d36a978058eb6757617fe4dc4bd6bad3";
$text_translate = $txt_dich; //Van ban dich ra. Tối đa 10.000 kí tự nha
$text_translate =trim(str_replace(" ","+",$text_translate)); // Dung khi cau dich co khoang trang
$lang = "en-vi"; // Dich tu Tieng Anh sang tieng Viet en-vi
$url_xml = file_get_contents("https://translate.yandex.net/api/v1.5/tr/translate?key=".$yandex_key."&text=".$text_translate."&lang=".$lang);
$xml=simplexml_load_string($url_xml); //Vi ket qua tra ve o dang XML nen ta dung ham nay de xuat Text tra ve
echo $xml->text; //-&amp;gt; là dấu mũi tên phải nhá. Bạn sửa lại (nếu bị lỗi) 

//Ket qua: Xin chào
} else {
    echo "fail!";
}
} else {
    echo "fail!";
}